#ifndef HAVE_PTHREAD
#define HAVE_PTHREAD
#endif
